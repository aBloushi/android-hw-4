package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.media.Image;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MoreInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_info);

        ImageView img = findViewById(R.id.imageView5);


        Bundle get = getIntent().getExtras();

        Pokemon p = (Pokemon) get.getSerializable("pokemon");


        TextView name = findViewById(R.id.textView5);
        TextView attack = findViewById(R.id.textView6);
        TextView defence = findViewById(R.id.textView7);
        TextView total = findViewById(R.id.textView8);

        img.setImageResource(p.getImage());
        name.setText("Name: " + p.getName() + "");
        total.setText("Total: " + p.getTotal() + "");
        attack.setText("Attack: " + p.getAttack() + "");
        defence.setText("Defence: " + p.getDefence() + "");


        //another way

//        img.setImageResource(get.getInt("image"));
//        name.setText("Name: " + get.getString("name"));
//        total.setText("Total: " + get.getString("total"));
//        attack.setText("Attack: " + get.getString("attack"));
//        defence.setText("Defence: " + get.getString("defence"));


    }
}