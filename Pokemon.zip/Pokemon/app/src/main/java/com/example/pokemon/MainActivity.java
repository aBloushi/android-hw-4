package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.rec);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));


        Pokemon Nidoqueen = new Pokemon("Nidoqueen",R.drawable.nidoqueen,92,87,505);
        Pokemon Butterfree = new Pokemon("Butterfree",R.drawable.butterfree,45,50,395);
        Pokemon Pikachu = new Pokemon("Pikachu",R.drawable.pikachu,55,40,320);
        Pokemon Blastoise = new Pokemon("Blastoise",R.drawable.blastoise,83,100,530);
        Pokemon Golbat = new Pokemon("Golbat",R.drawable.golbat,80,70,455);


        ArrayList<Pokemon> pokeball = new ArrayList<>();

        pokeball.add(Nidoqueen);
        pokeball.add(Butterfree);
        pokeball.add(Pikachu);
        pokeball.add(Blastoise);
        pokeball.add(Golbat);




        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);

        PokemonAdapter ad = new PokemonAdapter(pokeball,this);
        rv.setAdapter(ad);
    }
}