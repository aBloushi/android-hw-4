package com.example.pokemon;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PokemonAdapter extends RecyclerView.Adapter {

    ArrayList<Pokemon> pArray;
    Context context;



    public PokemonAdapter(ArrayList<Pokemon> pArray,Context context){
        this.pArray = pArray;
        this.context = context;

    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rvlayout,parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
//        final int image = pArray.get(position).getImage();
//        final String total = pArray.get(position).getTotal()+"";
//        final String name = pArray.get(position).getName()+"";
//        final String attack = pArray.get(position).getAttack()+"";
//        final String defence = pArray.get(position).getDefence()+"";

        ((ViewHolder) holder).img.setImageResource(pArray.get(position).getImage());
        ((ViewHolder) holder).total.setText(pArray.get(position).getTotal()+"");
        ((ViewHolder) holder).name.setText(pArray.get(position).getName()+"");


        ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context,MoreInfo.class);
                intent.putExtra("pokemon",pArray.get(position));


                //another way
//                intent.putExtra("image",image);
//                intent.putExtra("total",total);
//                intent.putExtra("attack",attack);
//                intent.putExtra("defence",defence);
//                intent.putExtra("name",name);


                context.startActivity(intent);

            }
        });
        ((ViewHolder) holder).delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pArray.remove(position);
                notifyDataSetChanged();
            }
        });


    }

    @Override
    public int getItemCount() {
        return pArray.size();
    }
    public  static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView img;
        public TextView name;
        public TextView total;
        public View view;
        public ImageView delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
           img = itemView.findViewById(R.id.imageView);
            name = itemView.findViewById(R.id.textView);
            total = itemView.findViewById(R.id.textView3);
            delete = itemView.findViewById(R.id.delete);

        }


    }


}
